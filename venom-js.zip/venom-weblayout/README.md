# venom — учебный проект Glo Academy 
## Проект выполнил: Иванов Иван

В проекте используются: 
- HTML 
- CSS 
- Javascript 
- Normalize
